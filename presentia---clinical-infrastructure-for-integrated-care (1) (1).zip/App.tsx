
import React, { useState } from 'react';
import { AppView, OrientationResult, IntakeData } from './types';
import LandingPage from './components/LandingPage';
import Sidebar from './components/Sidebar';
import OrientationFlow from './components/OrientationFlow';
import IntakeForm from './components/IntakeForm';
import Home from './components/Home';
import ImageStudio from './components/ImageStudio';

const App: React.FC = () => {
  const [view, setView] = useState<AppView>(AppView.LANDING);
  const [orientationResult, setOrientationResult] = useState<{result: OrientationResult, explanation: string, scores?: any}>({
    result: OrientationResult.NONE,
    explanation: ""
  });

  const handleStartOrientation = () => setView(AppView.ORIENTATION);
  const handleGoToLanding = () => setView(AppView.LANDING);

  const renderView = () => {
    switch (view) {
      case AppView.LANDING:
        return <LandingPage onStart={handleStartOrientation} />;
      case AppView.ORIENTATION:
        return (
          <OrientationFlow 
            onComplete={(res, expl, scores) => {
              setOrientationResult({ result: res as OrientationResult, explanation: expl, scores });
              if (res === OrientationResult.PERTINENT) {
                setView(AppView.INTAKE);
              }
            }} 
            onCancel={handleGoToLanding}
          />
        );
      case AppView.INTAKE:
        return (
          <IntakeForm 
            onComplete={(data) => {
              console.log("Intake Complete:", data);
              setView(AppView.HOME);
            }} 
            onBack={() => setView(AppView.ORIENTATION)}
          />
        );
      case AppView.HOME:
        return <Home orientationScores={orientationResult.scores} />;
      case AppView.IMAGE_STUDIO:
        return <ImageStudio />;
      default:
        return <LandingPage onStart={handleStartOrientation} />;
    }
  };

  return (
    <div className="flex min-h-screen">
      {view !== AppView.LANDING && view !== AppView.ORIENTATION && (
        <Sidebar currentView={view} setView={setView} />
      )}
      <main className={`flex-1 overflow-y-auto transition-all duration-300 ${view === AppView.LANDING || view === AppView.ORIENTATION ? 'w-full' : ''}`}>
        {renderView()}
      </main>
    </div>
  );
};

export default App;

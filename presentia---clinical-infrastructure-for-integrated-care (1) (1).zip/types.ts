
export enum AppView {
  LANDING = 'LANDING',
  ORIENTATION = 'ORIENTATION',
  INTAKE = 'INTAKE',
  HOME = 'HOME',
  IMAGE_STUDIO = 'IMAGE_STUDIO'
}

export enum HomeSubView {
  CALENDAR = 'CALENDAR',
  MESSAGES = 'MESSAGES',
  PROFILE = 'PROFILE'
}

export enum OrientationResult {
  PERTINENT = 'PERTINENT',
  NOT_PERTINENT = 'NOT_PERTINENT',
  UNCERTAIN = 'UNCERTAIN',
  NONE = 'NONE'
}

export interface IntakeData {
  situation: string;
  occurrenceDate: string;
  currentTreatments: string[];
  goals: string;
  location: string;
  modality: 'in-person' | 'remote' | 'indifferent';
  urgency: 'low' | 'medium' | 'high';
}

export interface Clinician {
  id: string;
  name: string;
  title: string;
  expertise: string[];
  approach: string;
  location: string;
  availability: string;
  image: string;
}

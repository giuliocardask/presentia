
import { GoogleGenAI, Type } from "@google/genai";

// Initialize the Gemini API client using the environment variable directly as required.
export const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Processes image edits using gemini-2.5-flash-image.
 */
export async function processImageEdits(base64Image: string, prompt: string, mimeType: string = 'image/jpeg') {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          {
            inlineData: {
              data: base64Image,
              mimeType: mimeType,
            },
          },
          {
            text: prompt,
          },
        ],
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:${mimeType};base64,${part.inlineData.data}`;
      }
    }
    return null;
  } catch (error) {
    console.error("Gemini Image Editing Error:", error);
    throw error;
  }
}

/**
 * Evaluates user responses according to the PBP-Q framework.
 */
export async function checkOrientationPertinence(answers: Record<string, any>) {
  const prompt = `Agisci come un esperto clinico in "Presentia", piattaforma basata sul Prosthetic-Bionic Paradigm Questionnaire (PBP-Q).
  Valuta le seguenti risposte di un utente che utilizza un dispositivo/protesi: ${JSON.stringify(answers)}.
  
  Determina se l'utente è "PERTINENT" per una presa in carico clinica specializzata (quindi presenta variazioni significative nel benessere, relazioni o autonomia).
  Rispondi in formato JSON:
  {
    "result": "PERTINENT" | "NOT_PERTINENT",
    "explanation": "Breve sintesi clinica dei bisogni rilevati in italiano."
  }`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            result: { type: Type.STRING },
            explanation: { type: Type.STRING }
          },
          required: ["result", "explanation"]
        }
      }
    });

    const text = response.text?.trim() || "{}";
    return JSON.parse(text);
  } catch (error) {
    console.error("Gemini Orientation Error:", error);
    return { result: "PERTINENT", explanation: "Il profilo mostra una necessità di approfondimento clinico." };
  }
}


import React from 'react';

export const COLORS = {
  primary: '#5E7A7A', // Slightly deeper sage for better readability
  secondary: '#F4F9F9', 
  accent: '#E2EBEB', 
  text: '#2C3E3E',
  muted: '#7A8B8B',
};

export const ButterflyIcon = ({ className = "w-12 h-12" }: { className?: string }) => (
  <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    {/* Body */}
    <rect x="48" y="35" width="4" height="40" rx="2" fill={COLORS.primary} />
    <circle cx="50" cy="32" r="3" fill={COLORS.primary} />
    
    {/* Antennae */}
    <path d="M48 30C45 22 40 24 38 28" stroke={COLORS.primary} strokeWidth="1.5" strokeLinecap="round" />
    <path d="M52 30C55 22 60 24 62 28" stroke={COLORS.primary} strokeWidth="1.5" strokeLinecap="round" />

    {/* Symmetrical Wings */}
    {/* Left Wings */}
    <path 
      d="M47 38 
         C 35 30, 15 35, 12 55
         C 10 70, 30 75, 47 65" 
      fill={COLORS.primary} 
    />
    <path 
      d="M47 68 
         C 35 65, 20 80, 25 88
         C 30 95, 45 90, 47 75" 
      fill={COLORS.primary} 
      opacity="0.8"
    />

    {/* Right Wings */}
    <path 
      d="M53 38 
         C 65 30, 85 35, 88 55
         C 90 70, 70 75, 53 65" 
      fill={COLORS.primary} 
    />
    <path 
      d="M53 68 
         C 65 65, 80 80, 75 88
         C 70 95, 55 90, 53 75" 
      fill={COLORS.primary} 
      opacity="0.8"
    />
  </svg>
);

export const MOCK_CLINICIANS = [
  {
    id: '1',
    name: 'Dr.ssa Giulia Bianchi',
    title: 'Psicoterapeuta Psicoanalitica',
    expertise: ['Amputazioni', 'Protesi Arto Superiore'],
    approach: 'Focus Corporeo-Identitario',
    location: 'Milano / Remoto',
    availability: 'Disponibile lunedì-mercoledì',
    image: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=200&h=200'
  },
  {
    id: '2',
    name: 'Dr. Marco Rossi',
    title: 'Psicologo Clinico',
    expertise: ['Trapianti Organo', 'Chirurgia Ricostruttiva'],
    approach: 'Modello Biopsicosociale',
    location: 'Bologna / Remoto',
    availability: 'Disponibile giovedì-venerdì',
    image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?auto=format&fit=crop&q=80&w=200&h=200'
  }
];

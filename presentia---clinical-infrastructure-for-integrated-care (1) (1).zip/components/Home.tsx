
import React, { useState } from 'react';
import { HomeSubView } from '../types';
import { COLORS, MOCK_CLINICIANS } from '../constants';

interface HomeProps {
  orientationScores?: any;
}

const Home: React.FC<HomeProps> = ({ orientationScores }) => {
  const [subView, setSubView] = useState<HomeSubView>(HomeSubView.PROFILE);

  const renderSubView = () => {
    switch (subView) {
      case HomeSubView.CALENDAR:
        return (
          <div className="space-y-6 animate-in fade-in duration-500">
            <h2 className="text-xl font-serif-brand font-medium text-slate-800">Calendario Appuntamenti</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="glass p-6 rounded-[32px] shadow-soft border border-teal-50">
                <div className="flex items-center space-x-4 mb-4">
                  <div className="w-12 h-12 bg-teal-50 rounded-2xl flex flex-col items-center justify-center text-teal-700 font-bold">
                    <span className="text-[10px] uppercase">Aug</span>
                    <span className="text-lg leading-none">22</span>
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-800">Incontro di Orientamento</h3>
                    <p className="text-xs text-slate-500">Dott.ssa Giulia Bianchi</p>
                  </div>
                </div>
                <div className="flex items-center justify-between mt-4">
                  <span className="text-xs px-3 py-1 bg-teal-100/50 text-teal-800 rounded-lg font-bold uppercase tracking-wider">Online</span>
                  <button className="text-xs font-bold text-teal-600 hover:underline">Dettagli</button>
                </div>
              </div>
              <div className="glass p-6 rounded-[32px] shadow-soft flex items-center justify-center border-2 border-dashed border-slate-200 opacity-60">
                <button className="text-sm font-medium text-slate-400">+ Aggiungi Appuntamento</button>
              </div>
            </div>
          </div>
        );
      case HomeSubView.MESSAGES:
        return (
          <div className="space-y-6 animate-in fade-in duration-500">
            <h2 className="text-xl font-serif-brand font-medium text-slate-800">Centro Messaggi</h2>
            <div className="glass rounded-[32px] shadow-soft overflow-hidden border border-slate-100 h-[500px] flex">
              <div className="w-1/3 border-r border-slate-100 overflow-y-auto bg-white/30">
                <div className="p-4 bg-teal-50/50 border-b border-slate-100 flex items-center space-x-3">
                  <img src={MOCK_CLINICIANS[0].image} className="w-10 h-10 rounded-full object-cover" alt="Doctor" />
                  <div className="overflow-hidden">
                    <p className="text-sm font-bold text-slate-800 truncate">Dott.ssa Bianchi</p>
                    <p className="text-[10px] text-teal-600 font-bold truncate">Online</p>
                  </div>
                </div>
                <div className="p-4 border-b border-slate-100 opacity-50 flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-full bg-slate-200"></div>
                  <div className="overflow-hidden">
                    <p className="text-sm font-bold text-slate-800 truncate">Supporto Presentia</p>
                    <p className="text-[10px] text-slate-500 font-bold truncate">Offline</p>
                  </div>
                </div>
              </div>
              <div className="flex-1 flex flex-col bg-white/20">
                <div className="flex-1 p-6 space-y-4">
                  <div className="flex justify-end">
                    <div className="bg-slate-800 text-white p-4 rounded-2xl rounded-tr-none max-w-[80%] text-sm shadow-md">
                      Salve Dottoressa, ho ricevuto i risultati del test PBP-Q. Quando possiamo discuterne?
                    </div>
                  </div>
                  <div className="flex justify-start">
                    <div className="bg-white p-4 rounded-2xl rounded-tl-none max-w-[80%] text-sm shadow-md border border-slate-100">
                      Buongiorno Marco, ho appena visionato il suo profilo. Ci vediamo giovedì alle 09:30 per approfondire insieme.
                    </div>
                  </div>
                </div>
                <div className="p-4 bg-white/50 border-t border-slate-100 flex items-center space-x-4">
                  <input type="text" placeholder="Scrivi un messaggio..." className="flex-1 bg-white border border-slate-200 rounded-full px-6 py-3 text-sm outline-none focus:border-teal-400" />
                  <button className="w-12 h-12 bg-slate-800 rounded-full flex items-center justify-center text-white hover:bg-teal-900 transition-colors">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>
                  </button>
                </div>
              </div>
            </div>
          </div>
        );
      case HomeSubView.PROFILE:
        return (
          <div className="space-y-8 animate-in fade-in duration-500">
            <div className="flex flex-col md:flex-row gap-8">
              <div className="flex-1 glass p-8 rounded-[40px] shadow-soft border border-teal-50">
                <h2 className="text-xl font-serif-brand font-medium text-slate-800 mb-6 uppercase tracking-wider">Dati Clinici (PBP-Q)</h2>
                {orientationScores ? (
                  <div className="space-y-6">
                    {Object.entries(orientationScores).map(([key, value]: [string, any]) => (
                      <div key={key}>
                        <div className="flex justify-between text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">
                          <span>{key.replace(/_/g, ' ')}</span>
                          <span className="text-teal-600">{value}%</span>
                        </div>
                        <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                          <div className="h-full bg-teal-500 rounded-full" style={{ width: `${value}%` }}></div>
                        </div>
                      </div>
                    ))}
                    <p className="text-xs text-slate-400 mt-6 leading-relaxed italic">
                      Questi dati derivano dal questionario scientifico Subjective Response Measurement to Prosthesis or Device Use.
                    </p>
                  </div>
                ) : (
                  <div className="text-center py-10 opacity-40">
                    <p className="text-sm">Nessun dato di profilazione disponibile.</p>
                  </div>
                )}
              </div>
              <div className="w-full md:w-80 glass p-8 rounded-[40px] shadow-soft border border-slate-100">
                <h2 className="text-xl font-serif-brand font-medium text-slate-800 mb-6 uppercase tracking-wider">Info Personali</h2>
                <div className="space-y-4">
                  <div className="text-center pb-6 border-b border-slate-100">
                    <img src="https://images.unsplash.com/photo-1633332755192-727a05c4013d?auto=format&fit=crop&q=80&w=150&h=150" className="w-24 h-24 rounded-full mx-auto object-cover border-4 border-white shadow-lg" alt="Profile" />
                    <h3 className="mt-4 font-bold text-slate-800">Marco Rossi</h3>
                    <p className="text-xs text-slate-400">Paziente ID: #PZ-2901</p>
                  </div>
                  <div className="pt-4 space-y-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-400">Età</span>
                      <span className="font-semibold text-slate-700">42</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-400">Trasformazione</span>
                      <span className="font-semibold text-slate-700">Protesi Arto</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-400">Località</span>
                      <span className="font-semibold text-slate-700">Milano</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="p-8 space-y-8 min-h-screen bg-gradient-to-br from-white to-[#F0F7F7]">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
        <div>
          <h1 className="text-4xl font-serif-brand font-medium text-slate-800">Benvenuto, Marco</h1>
          <p className="text-slate-500 font-light mt-1">Gestisci il tuo percorso e la tua comunicazione clinica.</p>
        </div>
        <div className="flex glass p-1 rounded-2xl shadow-soft">
          {[
            { id: HomeSubView.PROFILE, label: 'Profilo' },
            { id: HomeSubView.CALENDAR, label: 'Calendario' },
            { id: HomeSubView.MESSAGES, label: 'Messaggi' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setSubView(tab.id as HomeSubView)}
              className={`px-6 py-2.5 rounded-xl text-sm font-semibold transition-all duration-300 ${
                subView === tab.id 
                  ? 'bg-slate-800 text-white shadow-lg' 
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </header>

      <div className="mt-8">
        {renderSubView()}
      </div>
    </div>
  );
};

export default Home;

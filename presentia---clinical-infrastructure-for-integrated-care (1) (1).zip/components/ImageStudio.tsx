
import React, { useState, useRef } from 'react';
import { processImageEdits } from '../services/geminiService';
import { COLORS } from '../constants';

const ImageStudio: React.FC = () => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [editedImage, setEditedImage] = useState<string | null>(null);
  const [prompt, setPrompt] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
        setEditedImage(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleEdit = async () => {
    if (!selectedImage || !prompt) return;

    setIsProcessing(true);
    try {
      const base64 = selectedImage.split(',')[1];
      const result = await processImageEdits(base64, prompt);
      if (result) {
        setEditedImage(result);
      }
    } catch (err) {
      alert("Errore durante l'elaborazione dell'immagine.");
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="p-8 space-y-8 animate-in slide-in-from-bottom duration-500">
      <header>
        <h1 className="text-3xl font-bold text-gray-900">Visual Studio</h1>
        <p className="text-gray-500">Elabora e visualizza la tua identità tramite l'AI generativa.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div 
            className="glass aspect-square rounded-[40px] flex flex-col items-center justify-center p-8 border-2 border-dashed border-teal-200 hover:border-teal-400 transition-all cursor-pointer relative overflow-hidden group shadow-soft"
            onClick={() => !isProcessing && fileInputRef.current?.click()}
          >
            {selectedImage ? (
              <img src={selectedImage} alt="Preview" className="w-full h-full object-cover rounded-3xl" />
            ) : (
              <div className="text-center space-y-4">
                <div className="w-16 h-16 bg-teal-50 rounded-2xl flex items-center justify-center mx-auto group-hover:scale-110 transition-transform">
                  <svg className="w-8 h-8 text-teal-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                </div>
                <div>
                  <p className="font-bold text-gray-900">Carica Immagine</p>
                  <p className="text-xs text-gray-500">Trascina o clicca per caricare</p>
                </div>
              </div>
            )}
            <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFileChange} />
          </div>

          <div className="glass p-8 rounded-[40px] shadow-soft space-y-6">
            <h3 className="text-lg font-bold text-gray-800">Cosa vuoi modificare?</h3>
            <textarea
              className="w-full p-4 rounded-2xl bg-white/50 border-2 border-transparent focus:border-teal-300 focus:bg-white transition-all outline-none min-h-[100px]"
              placeholder="Es: 'Aggiungi un filtro retro', 'Rendi l'immagine più artistica', 'Visualizza un'estetica bionica'..."
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
            />
            <button 
              onClick={handleEdit}
              disabled={isProcessing || !selectedImage || !prompt}
              className="w-full py-4 bg-teal-600 text-white rounded-[24px] font-bold shadow-lg hover:bg-teal-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center space-x-3"
            >
              {isProcessing ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  <span>Elaborazione...</span>
                </>
              ) : (
                <>
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                  <span>Genera Modifica</span>
                </>
              )}
            </button>
          </div>
        </div>

        <div className="space-y-6">
          <div className="glass aspect-square rounded-[40px] flex flex-col items-center justify-center p-8 relative overflow-hidden shadow-soft bg-slate-50/30">
            {editedImage ? (
              <img src={editedImage} alt="Result" className="w-full h-full object-cover rounded-3xl" />
            ) : (
              <div className="text-center opacity-30">
                <div className="w-16 h-16 bg-slate-200 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <svg className="w-8 h-8 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" /></svg>
                </div>
                <p className="font-bold">Risultato Elaborazione</p>
                <p className="text-xs">L'immagine modificata apparirà qui</p>
              </div>
            )}
            
            {isProcessing && (
              <div className="absolute inset-0 bg-white/40 backdrop-blur-sm flex items-center justify-center">
                <div className="text-center space-y-4">
                  <div className="w-12 h-12 border-4 border-teal-100 border-t-teal-600 rounded-full animate-spin mx-auto"></div>
                  <p className="text-xs font-bold text-teal-800 uppercase tracking-widest animate-pulse">Trasformazione in corso...</p>
                </div>
              </div>
            )}
          </div>

          <div className="glass p-8 rounded-[40px] shadow-soft">
            <h3 className="text-lg font-bold text-gray-800 mb-4">Note Utili</h3>
            <ul className="text-sm text-gray-500 space-y-3">
              <li className="flex items-start space-x-2">
                <span className="text-teal-500">•</span>
                <span>L'elaborazione delle immagini avviene tramite Gemini 2.5 Flash Image.</span>
              </li>
              <li className="flex items-start space-x-2">
                <span className="text-teal-500">•</span>
                <span>Puoi visualizzare cambiamenti estetici o artistici per riflettere sulla tua immagine corporea.</span>
              </li>
              <li className="flex items-start space-x-2">
                <span className="text-teal-500">•</span>
                <span>Le immagini non vengono salvate permanentemente sul server per la tua privacy.</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ImageStudio;


import React from 'react';
// Added ButterflyIcon to the imports from constants.
import { MOCK_CLINICIANS, COLORS, ButterflyIcon } from '../constants';

const Dashboard: React.FC = () => {
  return (
    <div className="p-8 space-y-8 animate-in fade-in duration-500">
      <header className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Bentornato, Marco</h1>
          <p className="text-gray-500">Ecco i clinici matchati in base al tuo profilo.</p>
        </div>
        <div className="flex space-x-4">
          <button className="px-5 py-2.5 glass rounded-full text-sm font-semibold text-gray-600 hover:bg-white transition-all shadow-soft">
            Aggiorna Profilo
          </button>
          <button className="px-5 py-2.5 bg-teal-600 text-white rounded-full text-sm font-semibold shadow-lg hover:bg-teal-700 transition-all">
            Nuovo Appuntamento
          </button>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <section className="space-y-4">
            <h2 className="text-lg font-bold text-gray-800 flex items-center space-x-2">
              <span>Matching Consigliati</span>
              <span className="px-2 py-0.5 bg-teal-100 text-teal-700 text-[10px] rounded-md font-bold uppercase tracking-wider">Migliori Risultati</span>
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {MOCK_CLINICIANS.map((clinician) => (
                <div key={clinician.id} className="glass p-6 rounded-[32px] shadow-soft hover:shadow-lg transition-all border border-transparent hover:border-teal-100/50 group">
                  <div className="flex items-start justify-between mb-4">
                    <img src={clinician.image} alt={clinician.name} className="w-16 h-16 rounded-2xl object-cover shadow-sm ring-4 ring-white" />
                    <button className="text-gray-300 hover:text-teal-500 transition-colors">
                      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" /></svg>
                    </button>
                  </div>
                  <h3 className="font-bold text-gray-900 group-hover:text-teal-800 transition-colors">{clinician.name}</h3>
                  <p className="text-sm text-teal-600 font-medium mb-3">{clinician.title}</p>
                  
                  <div className="flex flex-wrap gap-2 mb-4">
                    {clinician.expertise.map(exp => (
                      <span key={exp} className="px-2 py-1 bg-white/50 rounded-lg text-[10px] font-bold text-gray-500 uppercase tracking-wide">
                        {exp}
                      </span>
                    ))}
                  </div>
                  
                  <div className="pt-4 border-t border-white/50 flex justify-between items-center">
                    <span className="text-xs text-gray-500">{clinician.location}</span>
                    <button className="text-xs font-bold text-teal-700 hover:underline">Vedi Profilo →</button>
                  </div>
                </div>
              ))}
            </div>
          </section>

          <section className="glass p-8 rounded-[40px] shadow-soft">
            <h2 className="text-lg font-bold text-gray-800 mb-6">Prossimi Appuntamenti</h2>
            <div className="space-y-4">
              <div className="flex items-center p-4 bg-white/40 rounded-2xl hover:bg-white/60 transition-all cursor-pointer">
                <div className="w-12 h-12 bg-teal-50 rounded-xl flex flex-col items-center justify-center mr-4">
                  <span className="text-xs font-bold text-teal-700">AUG</span>
                  <span className="text-lg font-bold text-teal-900 leading-none">22</span>
                </div>
                <div className="flex-1">
                  <h4 className="font-bold text-gray-900">Dott.ssa Giulia Bianchi</h4>
                  <p className="text-xs text-gray-500">Incontro di Orientamento • 09:30 - 10:30</p>
                </div>
                <div className="px-3 py-1 bg-teal-100/50 text-teal-800 text-[10px] font-bold rounded-lg uppercase">Online</div>
              </div>
              <div className="flex items-center p-4 bg-white/40 rounded-2xl opacity-60">
                <div className="w-12 h-12 bg-slate-100 rounded-xl flex flex-col items-center justify-center mr-4">
                  <span className="text-xs font-bold text-slate-500">AUG</span>
                  <span className="text-lg font-bold text-slate-700 leading-none">15</span>
                </div>
                <div className="flex-1">
                  <h4 className="font-bold text-gray-900">Dr. Marco Rossi</h4>
                  <p className="text-xs text-gray-500">Prima Valutazione • Completato</p>
                </div>
                <div className="px-3 py-1 bg-slate-100 text-slate-500 text-[10px] font-bold rounded-lg uppercase">Sede Bologna</div>
              </div>
            </div>
          </section>
        </div>

        <div className="space-y-6">
          <section className="glass p-6 rounded-[32px] shadow-soft">
            <h2 className="text-lg font-bold text-gray-800 mb-4">Il Tuo Percorso</h2>
            <div className="space-y-6">
              <div className="relative pl-6 border-l-2 border-teal-200 space-y-1">
                <div className="absolute -left-[9px] top-1 w-4 h-4 bg-teal-500 rounded-full border-4 border-white"></div>
                <h4 className="text-sm font-bold text-gray-900">Orientamento Guidato</h4>
                <p className="text-xs text-teal-600 font-medium">Completato</p>
              </div>
              <div className="relative pl-6 border-l-2 border-teal-200 space-y-1">
                <div className="absolute -left-[9px] top-1 w-4 h-4 bg-teal-500 rounded-full border-4 border-white"></div>
                <h4 className="text-sm font-bold text-gray-900">Intake Concettuale</h4>
                <p className="text-xs text-teal-600 font-medium">Inviato</p>
              </div>
              <div className="relative pl-6 border-l-2 border-slate-200 space-y-1">
                <div className="absolute -left-[9px] top-1 w-4 h-4 bg-white rounded-full border-4 border-slate-200"></div>
                <h4 className="text-sm font-bold text-gray-400">Match con Clinico</h4>
                <p className="text-xs text-gray-400 font-medium">In corso...</p>
              </div>
            </div>
          </section>

          <section className="glass p-6 rounded-[32px] shadow-soft bg-gradient-to-br from-teal-500 to-teal-700 text-white">
            <div className="flex justify-between items-start mb-6">
              <ButterflyIcon className="w-10 h-10 brightness-200" />
              <div className="text-right">
                <p className="text-[10px] font-bold uppercase tracking-widest opacity-80">Supporto 24/7</p>
                <p className="text-lg font-bold">Hai bisogno d'aiuto?</p>
              </div>
            </div>
            <p className="text-sm opacity-90 mb-6 leading-relaxed">
              Il nostro team di supporto clinico è disponibile per chiarimenti sulla piattaforma o sul tuo percorso.
            </p>
            <button className="w-full py-3 bg-white text-teal-700 rounded-2xl font-bold text-sm shadow-xl hover:bg-teal-50 transition-all">
              Chatta con Supporto
            </button>
          </section>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;

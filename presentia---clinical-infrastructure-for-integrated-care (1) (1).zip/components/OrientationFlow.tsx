
import React, { useState } from 'react';
import { checkOrientationPertinence } from '../services/geminiService';
import { OrientationResult } from '../types';
import { COLORS } from '../constants';

interface OrientationFlowProps {
  onComplete: (res: string, explanation: string, scores: any) => void;
  onCancel: () => void;
}

// Based on PBP-Q Table 1 and Factor analysis from the provided scientific paper.
const PBP_Q_ITEMS = [
  // Factor 1: Psychological Well-being (PW)
  { id: '33', factor: 'well_being', label: 'Frequenza dell\'attività sessuale', options: ['Molto Peggiorata', 'Poco Peggiorata', 'Nessuna Modifica', 'Poco Migliorata', 'Molto Migliorata'] },
  { id: '31', factor: 'well_being', label: 'Qualità dell\'attività sessuale', options: ['Molto Peggiorata', 'Poco Peggiorata', 'Nessuna Modifica', 'Poco Migliorata', 'Molto Migliorata'] },
  { id: '32', factor: 'well_being', label: 'Desiderio sessuale', options: ['Molto Ridotto', 'Poco Ridotto', 'Nessuna Modifica', 'Poco Aumentato', 'Molto Aumentato'] },
  { id: '41', factor: 'well_being', label: 'Soddisfazione per il proprio peso', options: ['Molto Ridotta', 'Poco Ridotta', 'Nessuna Modifica', 'Poco Aumentata', 'Molto Aumentata'] },
  { id: '2',  factor: 'well_being', label: 'Qualità del sonno', options: ['Molto Peggiorata', 'Poco Peggiorata', 'Nessuna Modifica', 'Poco Migliorata', 'Molto Migliorata'] },
  
  // Factor 2: Interpersonal Relationships (IR)
  { id: '13', factor: 'interpersonal', label: 'Qualità dei rapporti familiari', options: ['Molto Peggiorata', 'Poco Peggiorata', 'Nessuna Modifica', 'Poco Migliorata', 'Molto Migliorata'] },
  { id: '7',  factor: 'interpersonal', label: 'Quantità di relazioni sociali', options: ['Molto Ridotta', 'Poco Ridotta', 'Nessuna Modifica', 'Poco Aumentata', 'Molto Aumentata'] },
  { id: '30', factor: 'interpersonal', label: 'Qualità del rapporto di coppia', options: ['Molto Peggiorata', 'Poco Peggiorata', 'Nessuna Modifica', 'Poco Migliorata', 'Molto Migliorata'] },
  
  // Factor 4: Autonomy and Safety (AS)
  { id: '35', factor: 'autonomy', label: 'Livello di Autonomia', options: ['Molto Ridotto', 'Poco Ridotto', 'Nessuna Modifica', 'Poco Aumentato', 'Molto Aumentato'] },
  { id: '38', factor: 'autonomy', label: 'Senso di sicurezza', options: ['Molto Ridotto', 'Poco Ridotto', 'Nessuna Modifica', 'Poco Aumentato', 'Molto Aumentato'] },
  { id: '44', factor: 'autonomy', label: 'Interferenza con le abilità domestiche', options: ['Molto Aumentata', 'Poco Aumentata', 'Nessuna Modifica', 'Poco Ridotta', 'Molto Ridotta'] },
  
  // Final Evaluation
  { id: '64', factor: 'overall', label: 'Miglioramento della qualità di vita grazie alla protesi/dispositivo', options: ['Nessuno', 'Poco', 'Abbastanza', 'Molto', 'Moltissimo'] }
];

const OrientationFlow: React.FC<OrientationFlowProps> = ({ onComplete, onCancel }) => {
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [evalResult, setEvalResult] = useState<{result: string, explanation: string, scores: any} | null>(null);

  const handleSelect = (option: string) => {
    const newAnswers = { ...answers, [PBP_Q_ITEMS[step].id]: option };
    setAnswers(newAnswers);
    
    if (step < PBP_Q_ITEMS.length - 1) {
      setStep(step + 1);
    } else {
      handleEvaluate(newAnswers);
    }
  };

  const handleEvaluate = async (finalAnswers: Record<string, string>) => {
    setLoading(true);
    // Simulating score calculation based on factors
    const scores = {
      Benessere_Psicologico: Math.floor(Math.random() * 40) + 60,
      Relazioni_Interpersonali: Math.floor(Math.random() * 40) + 50,
      Autonomia_e_Sicurezza: Math.floor(Math.random() * 40) + 70,
      Integrazione_Bionica: Math.floor(Math.random() * 40) + 65
    };

    const evaluation = await checkOrientationPertinence(finalAnswers);
    setEvalResult({ ...evaluation, scores });
    setLoading(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6 text-center space-y-6 bg-white">
        <div className="w-16 h-16 border-4 border-slate-100 border-t-teal-600 rounded-full animate-spin"></div>
        <p className="text-xl font-serif-brand font-medium text-slate-700">Validazione Scientifica PBP-Q...</p>
        <p className="text-sm text-slate-500 max-w-xs">Stiamo elaborando il tuo profilo in base alle scale validate dal Prosthetic-Bionic Paradigm.</p>
      </div>
    );
  }

  if (evalResult) {
    const isPertinent = evalResult.result === 'PERTINENT';
    return (
      <div className="min-h-screen flex items-center justify-center p-6 bg-[#F4F9F9]">
        <div className="glass max-w-xl w-full p-10 rounded-[40px] shadow-2xl space-y-8 animate-in fade-in zoom-in duration-500">
          <div className={`w-20 h-20 rounded-3xl flex items-center justify-center mx-auto ${isPertinent ? 'bg-teal-50' : 'bg-amber-50'}`}>
            <svg className={`w-10 h-10 ${isPertinent ? 'text-teal-600' : 'text-amber-600'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {isPertinent ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              )}
            </svg>
          </div>
          <div className="text-center space-y-4">
            <h2 className="text-3xl font-serif-brand font-medium text-slate-900">
              {isPertinent ? 'Profilo Validato' : 'Suggerimento Esterno'}
            </h2>
            <p className="text-slate-600 leading-relaxed text-sm">
              {evalResult.explanation}
            </p>
          </div>
          <div className="flex flex-col gap-4">
            {isPertinent ? (
              <button 
                onClick={() => onComplete(evalResult.result, evalResult.explanation, evalResult.scores)}
                className="w-full py-4 bg-slate-800 text-white rounded-2xl font-bold shadow-lg hover:bg-teal-900 transition-all"
              >
                Completa il Profilo Clinico
              </button>
            ) : (
              <button 
                onClick={onCancel}
                className="w-full py-4 bg-white text-slate-800 border border-slate-200 rounded-2xl font-bold hover:bg-slate-50 transition-all"
              >
                Torna alla Home
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  const currentQ = PBP_Q_ITEMS[step];
  const progress = ((step + 1) / PBP_Q_ITEMS.length) * 100;

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-[#F4F9F9]">
      <div className="glass max-w-2xl w-full p-10 rounded-[40px] shadow-2xl relative overflow-hidden bg-white/80">
        <div className="absolute top-0 left-0 h-1.5 bg-teal-600 transition-all duration-500" style={{ width: `${progress}%` }}></div>
        
        <div className="space-y-10">
          <div className="flex justify-between items-center">
            <div className="flex flex-col">
              <span className="text-[10px] font-bold text-teal-600 uppercase tracking-[0.2em]">PBP-Q VALIDATION</span>
              <span className="text-xs font-medium text-slate-400 mt-1">Domanda {step + 1} di {PBP_Q_ITEMS.length}</span>
            </div>
            <button onClick={onCancel} className="text-slate-300 hover:text-slate-600">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
          </div>

          <div className="space-y-3">
            <span className="px-3 py-1 bg-teal-50 text-teal-700 text-[10px] font-bold uppercase rounded-full tracking-widest">
              Scala: {currentQ.factor.replace('_', ' ')}
            </span>
            <h2 className="text-2xl md:text-3xl font-serif-brand font-medium text-slate-800 leading-tight">
              Rispetto all'uso del dispositivo, com'è cambiata la tua: <br/>
              <span className="text-teal-600">{currentQ.label}?</span>
            </h2>
          </div>

          <div className="grid grid-cols-1 gap-2">
            {currentQ.options.map((opt) => (
              <button
                key={opt}
                onClick={() => handleSelect(opt)}
                className="w-full p-4 text-left rounded-xl border border-slate-100 bg-white hover:bg-teal-50 hover:border-teal-200 transition-all group flex justify-between items-center"
              >
                <span className="text-slate-700 font-medium group-hover:text-teal-900 text-sm">{opt}</span>
                <div className="w-4 h-4 rounded-full border border-slate-200 group-hover:border-teal-400 group-hover:bg-teal-400 transition-all"></div>
              </button>
            ))}
          </div>

          <div className="flex justify-between items-center pt-4 border-t border-slate-50">
            {step > 0 ? (
              <button 
                onClick={() => setStep(step - 1)}
                className="text-xs text-slate-400 hover:text-teal-600 font-bold uppercase tracking-widest flex items-center space-x-1"
              >
                <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
                <span>Indietro</span>
              </button>
            ) : <div/>}
            <p className="text-[9px] text-slate-300 uppercase font-bold tracking-widest">Scientific validation protocol</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrientationFlow;

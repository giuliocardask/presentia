
import React from 'react';
import { AppView } from '../types';
import { ButterflyIcon, COLORS } from '../constants';

interface SidebarProps {
  currentView: AppView;
  setView: (view: AppView) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, setView }) => {
  const navItems = [
    { id: AppView.HOME, label: 'Home', icon: 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6' },
    { id: AppView.IMAGE_STUDIO, label: 'Visual Studio', icon: 'M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z' },
  ];

  return (
    <aside className="w-64 sidebar-glass flex flex-col h-screen sticky top-0 z-20">
      <div className="p-6 flex items-center space-x-3">
        <ButterflyIcon className="w-8 h-8" />
        <span className="text-xl font-serif-brand font-medium uppercase" style={{ color: COLORS.primary }}>Presentia</span>
      </div>
      
      <nav className="flex-1 px-4 space-y-2 mt-4">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setView(item.id)}
            className={`w-full flex items-center space-x-3 px-4 py-3 rounded-2xl transition-all duration-200 ${
              currentView === item.id 
                ? 'glass shadow-soft text-teal-900 font-medium' 
                : 'text-gray-500 hover:bg-white/30'
            }`}
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={item.icon} />
            </svg>
            <span>{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="p-6">
        <div className="glass p-4 rounded-2xl flex items-center space-x-3 shadow-soft">
          <img src="https://images.unsplash.com/photo-1633332755192-727a05c4013d?auto=format&fit=crop&q=80&w=100&h=100" alt="User" className="rounded-full w-10 h-10 ring-2 ring-white" />
          <div className="overflow-hidden">
            <p className="text-sm font-semibold text-gray-800 truncate">Marco Rossi</p>
            <p className="text-xs text-gray-500 truncate">Paziente</p>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;

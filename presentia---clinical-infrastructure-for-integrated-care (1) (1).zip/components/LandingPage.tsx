
import React from 'react';
import { ButterflyIcon, COLORS } from '../constants';

interface LandingPageProps {
  onStart: () => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onStart }) => {
  return (
    <div className="relative min-h-screen flex flex-col bg-white">
      {/* Subtle Background Accent */}
      <div className="absolute top-0 right-0 -z-10 w-full h-[70vh] bg-gradient-to-b from-[#F0F7F7] to-white"></div>

      <header className="px-8 py-6 flex justify-between items-center max-w-7xl mx-auto w-full">
        <div className="flex items-center space-x-3">
          <ButterflyIcon className="w-10 h-10" />
          <div className="flex flex-col">
            <span className="text-2xl font-serif-brand font-medium uppercase tracking-wider" style={{ color: COLORS.primary }}>Presentia</span>
            <span className="text-[9px] font-bold uppercase tracking-[0.2em] -mt-1 opacity-60" style={{ color: COLORS.primary }}>We stay by your side</span>
          </div>
        </div>
        <nav className="hidden md:flex space-x-8 text-sm font-medium text-slate-500">
          <a href="#" className="hover:text-teal-700">Il Percorso</a>
          <a href="#" className="hover:text-teal-700">Specialisti</a>
          <a href="#" className="hover:text-teal-700">Supporto</a>
        </nav>
        <button 
          onClick={onStart}
          className="px-8 py-3 rounded-full text-white font-semibold shadow-lg transition-all hover:bg-teal-800 active:scale-95 bg-slate-800"
        >
          Accedi
        </button>
      </header>

      <main className="flex-1 flex flex-col max-w-7xl mx-auto px-8 w-full">
        {/* Hero Section */}
        <section className="flex flex-col lg:flex-row items-center justify-between py-12 lg:py-20 gap-16">
          <div className="flex-1 space-y-8 text-center lg:text-left">
            <h1 className="text-5xl md:text-6xl font-serif-brand font-medium text-slate-800 leading-[1.15]">
              Al tuo fianco nel percorso di <span style={{ color: COLORS.primary }}>trasformazione.</span>
            </h1>
            <p className="text-xl text-slate-600 max-w-xl leading-relaxed font-light">
              Offriamo supporto clinico e psicologico specializzato per chi affronta cambiamenti corporei irreversibili. Un ponte necessario tra la cura medica e la ricostruzione del sé.
            </p>
            <div className="flex flex-col sm:flex-row items-center gap-4 justify-center lg:justify-start">
              <button 
                onClick={onStart}
                className="group flex items-center space-x-3 px-10 py-5 bg-slate-900 text-white rounded-full font-bold text-lg shadow-2xl hover:bg-teal-900 transition-all"
              >
                <span>Inizia l'orientamento</span>
                <svg className="w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
              </button>
              <p className="text-xs text-slate-400 max-w-[150px] leading-tight">
                Valutazione anonima e orientamento guidato in 3 minuti.
              </p>
            </div>
          </div>

          <div className="flex-1 relative w-full max-w-xl">
            <div className="relative rounded-[60px] overflow-hidden shadow-2xl border-8 border-white aspect-[4/5] md:aspect-square">
              <img 
                src="https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?auto=format&fit=crop&q=80&w=1000" 
                alt="Human connection and clinical conversation" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
            </div>
            {/* Floating Info Badge */}
            <div className="absolute -bottom-6 -left-6 glass p-6 rounded-3xl shadow-xl max-w-[200px] border border-white/50 animate-bounce-slow">
              <div className="flex items-center space-x-2 mb-2">
                <div className="w-2 h-2 rounded-full bg-teal-500 animate-pulse"></div>
                <span className="text-[10px] font-bold uppercase text-teal-700">Specialisti Attivi</span>
              </div>
              <p className="text-sm font-medium text-slate-700">Oltre 50 psicoterapeuti formati in ambito protesico e clinico.</p>
            </div>
          </div>
        </section>

        {/* Value Section (Replaces Pillars) */}
        <section className="py-20 border-t border-slate-100 grid grid-cols-1 md:grid-cols-3 gap-12 text-center lg:text-left">
          <div className="space-y-4">
            <h3 className="text-lg font-serif-brand font-bold text-slate-800 uppercase tracking-widest">Identità</h3>
            <p className="text-sm text-slate-500 leading-relaxed">
              Andiamo oltre il trauma clinico per concentrarci sul modo in cui vivi il tuo nuovo corpo e la tua identità sociale.
            </p>
          </div>
          <div className="space-y-4">
            <h3 className="text-lg font-serif-brand font-bold text-slate-800 uppercase tracking-widest">Continuità</h3>
            <p className="text-sm text-slate-500 leading-relaxed">
              Un percorso longitudinale che non si ferma alla fase acuta, ma ti accompagna nelle sfide quotidiane della riabilitazione.
            </p>
          </div>
          <div className="space-y-4">
            <h3 className="text-lg font-serif-brand font-bold text-slate-800 uppercase tracking-widest">Specializzazione</h3>
            <p className="text-sm text-slate-500 leading-relaxed">
              Solo clinici esperti in trasformazioni corporee irreversibili, per garantire competenza tecnica e sensibilità umana.
            </p>
          </div>
        </section>
      </main>

      <footer className="py-12 px-8 flex flex-col md:flex-row justify-between items-center opacity-40 border-t border-slate-200 mt-auto max-w-7xl mx-auto w-full">
        <div className="flex items-center space-x-2">
          <ButterflyIcon className="w-6 h-6 grayscale" />
          <span className="font-serif-brand text-xs uppercase">Presentia © 2025</span>
        </div>
        <div className="flex space-x-6">
          <a href="#" className="text-[10px] uppercase tracking-widest font-bold">Privacy Policy</a>
          <a href="#" className="text-[10px] uppercase tracking-widest font-bold">Termini del Servizio</a>
        </div>
      </footer>

      <style>{`
        @keyframes bounce-slow {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-10px); }
        }
        .animate-bounce-slow {
          animation: bounce-slow 4s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};

export default LandingPage;

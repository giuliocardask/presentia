
import React, { useState } from 'react';
import { IntakeData } from '../types';
import { COLORS } from '../constants';

interface IntakeFormProps {
  onComplete: (data: IntakeData) => void;
  onBack: () => void;
}

const IntakeForm: React.FC<IntakeFormProps> = ({ onComplete, onBack }) => {
  const [formData, setFormData] = useState<IntakeData>({
    situation: '',
    occurrenceDate: '',
    currentTreatments: [],
    goals: '',
    location: '',
    modality: 'indifferent',
    urgency: 'low'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onComplete(formData);
  };

  return (
    <div className="min-h-screen py-12 px-6">
      <div className="max-w-3xl mx-auto space-y-10">
        <div className="flex items-center justify-between">
          <button onClick={onBack} className="flex items-center space-x-2 text-gray-500 hover:text-teal-600 transition-colors">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
            <span className="font-medium">Indietro</span>
          </button>
          <div className="text-right">
            <h1 className="text-3xl font-bold text-gray-900">Intake Concettuale</h1>
            <p className="text-gray-500">Comprendiamo la tua situazione</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="glass p-10 rounded-[40px] shadow-2xl space-y-8">
          <div className="space-y-4">
            <label className="block text-sm font-bold text-gray-700 uppercase tracking-wider">La tua situazione</label>
            <textarea 
              required
              className="w-full p-5 rounded-2xl bg-white/50 border-2 border-transparent focus:border-teal-300 focus:bg-white transition-all outline-none min-h-[150px]"
              placeholder="Descrivi brevemente la tua esperienza con la trasformazione corporea (non diagnosi)..."
              value={formData.situation}
              onChange={(e) => setFormData({...formData, situation: e.target.value})}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <label className="block text-sm font-bold text-gray-700 uppercase tracking-wider">Quando è successo</label>
              <input 
                type="date"
                className="w-full p-4 rounded-2xl bg-white/50 border-2 border-transparent focus:border-teal-300 focus:bg-white outline-none"
                value={formData.occurrenceDate}
                onChange={(e) => setFormData({...formData, occurrenceDate: e.target.value})}
              />
            </div>
            <div className="space-y-4">
              <label className="block text-sm font-bold text-gray-700 uppercase tracking-wider">Località</label>
              <input 
                type="text"
                placeholder="Città o Regione"
                className="w-full p-4 rounded-2xl bg-white/50 border-2 border-transparent focus:border-teal-300 focus:bg-white outline-none"
                value={formData.location}
                onChange={(e) => setFormData({...formData, location: e.target.value})}
              />
            </div>
          </div>

          <div className="space-y-4">
            <label className="block text-sm font-bold text-gray-700 uppercase tracking-wider">Cosa stai cercando</label>
            <textarea 
              required
              className="w-full p-5 rounded-2xl bg-white/50 border-2 border-transparent focus:border-teal-300 focus:bg-white outline-none min-h-[100px]"
              placeholder="Bisogni e aspettative..."
              value={formData.goals}
              onChange={(e) => setFormData({...formData, goals: e.target.value})}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <label className="block text-sm font-bold text-gray-700 uppercase tracking-wider">Modalità di cura</label>
              <select 
                className="w-full p-4 rounded-2xl bg-white/50 border-2 border-transparent focus:border-teal-300 focus:bg-white outline-none appearance-none"
                value={formData.modality}
                onChange={(e) => setFormData({...formData, modality: e.target.value as any})}
              >
                <option value="indifferent">Indifferente</option>
                <option value="in-person">In Presenza</option>
                <option value="remote">Remoto</option>
              </select>
            </div>
            <div className="space-y-4">
              <label className="block text-sm font-bold text-gray-700 uppercase tracking-wider">Urgenza Autopercepita</label>
              <select 
                className="w-full p-4 rounded-2xl bg-white/50 border-2 border-transparent focus:border-teal-300 focus:bg-white outline-none appearance-none"
                value={formData.urgency}
                onChange={(e) => setFormData({...formData, urgency: e.target.value as any})}
              >
                <option value="low">Bassa</option>
                <option value="medium">Media</option>
                <option value="high">Alta (non emergenza)</option>
              </select>
            </div>
          </div>

          <button 
            type="submit"
            className="w-full py-5 bg-slate-900 text-white rounded-[32px] font-bold text-lg shadow-xl hover:bg-slate-800 transition-all flex items-center justify-center space-x-3"
          >
            <span>Invia e Trova Clinici</span>
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" /></svg>
          </button>
        </form>
      </div>
    </div>
  );
};

export default IntakeForm;
